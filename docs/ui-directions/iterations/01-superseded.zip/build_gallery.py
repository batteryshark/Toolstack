"""Design artifacts only. Stdlib; fake data; no application imports or network."""
from pathlib import Path
from html import escape as E
import json

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'visuals'
OUT.mkdir(exist_ok=True)
INK, MUTED, LINE, BLUE, NAV = '#18202a', '#526173', '#d9dee7', '#0d6efd', '#172033'
DIRECTIONS = {
 'a': ('01 · Clear desk', 'Continuity first', 'Keep the navy top navigation and light document canvas. Wide forms, explicit receipts, and restrained blue actions.', 'Lowest visual migration cost; familiar web reference and native tabbed counterpart.', 'Longer pages and less persistent collection context than the workbench.'),
 'b': ('02 · Operator workbench', 'Context first', 'Move navigation into a navy rail; keep the selected caller or tool visible beside a focused inspector.', 'Best repeated operation across several tools; stable selection and state stay in view.', 'Three columns cost width and create more scanning; greater navigation change.'),
 'c': ('03 · Guided ledger', 'Sequence first', 'A light, blue-accented workspace gives each authority-changing stage its own page and a persistent scope ledger.', 'Clearest first-use distinction between adding, executing, registering, and granting.', 'More stage navigation for experts; must not become a new workflow engine.'),
}
FLOWS = {'grant': ('Caller access', ['Enable tool', 'Edit policy', 'Saved policy']),
         'add': ('Local folder', ['Add folder', 'Start tool', 'Register in broker']),
         'recover': ('Crash recovery', ['Inspect failure', 'Confirm restart', 'Check outcome'])}

class SVG:
 def __init__(self, title):
  self.s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="900" viewBox="0 0 1440 900" role="img" aria-label="{E(title)}"><title>{E(title)}</title>', '<style>text{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif} .mono{font-family:Menlo,monospace}</style>']
 def box(self,x,y,w,h,fill='#fff',stroke=LINE,r=8):
  self.s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}"/>')
 def text(self,x,y,t,size=17,color=INK,weight=400):
  self.s.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}">{E(t)}</text>')
 def lines(self,x,y,ls,size=17,color=MUTED):
  for i,t in enumerate(ls): self.text(x,y+i*26,t,size,color)
 def button(self,x,y,t,primary=False,w=220,disabled=False):
  self.box(x,y,w,42,'#edf0f4' if disabled else BLUE if primary else '#fff',BLUE if primary else LINE,6)
  self.text(x+14,y+27,t,16,'#76818e' if disabled else '#fff' if primary else INK,550)
 def badge(self,x,y,t,tone='neutral',w=170):
  bg,fg = {'neutral':('#eef1f5',MUTED),'bad':('#fff0f0','#8c1f1f'),'ok':('#e9f8ef','#176333'),'warn':('#fff6df','#765000'),'blue':('#eaf2ff','#154f9c')}[tone]
  self.box(x,y,w,30,bg,bg,15); self.text(x+12,y+21,t,15,fg,550)
 def row(self,x,y,w,label,value):
  self.box(x,y,w,49,'#fff',LINE,0); self.text(x+16,y+31,label,16); self.text(x+w-220,y+31,value,16,MUTED)
 def end(self): return ''.join(self.s)+'</svg>'

def screen(d,surface,flow,step):
 title = f'{DIRECTIONS[d][0]} / {surface} / {FLOWS[flow][0]} / {FLOWS[flow][1][step]}'
 p=SVG(title); p.box(0,0,1440,900,'#f6f7f9',LINE,0)
 native=surface=='mac'; shell=surface=='shell'
 p.box(0,0,1440,42,'#e9ecf1',LINE,0)
 for i,col in enumerate(['#ff6058','#ffbd2e','#28c840']):
  p.s.append(f'<circle cx="{22+i*23}" cy="21" r="6" fill="{col}"/>')
 p.text(110,27, 'Toolstack Operator' if native else 'Toolstack · desktop webview' if shell else 'Toolstack Admin — desktop web reference',15,INK,550)
 p.text(1020,27,'DESIGN MOCKUP · FICTIONAL DATA',14,MUTED)
 if native:
  p.box(0,42,1440,62,'#f4f5f7',LINE,0)
  p.text(26,81,'▤  Toolstack',23,INK,650)
  p.text(300,80,'Local admin · 127.0.0.1:8780',16,MUTED)
  p.text(1000,80,'Broker: running · health unknown',16,MUTED)
 else:
  p.box(0,42,1440,70,NAV,NAV,0); p.text(28,85,'▤  Toolstack',24,'#fff',650)
  if d!='b':
   for i,t in enumerate(['Dashboard','Tools','Config']):
    p.text(290+i*145,84,t,17,'#fff' if t==('Dashboard' if flow=='grant' else 'Tools') else '#c7d0dc',550)
  p.text(1060,84,'Local admin · operator-demo',16,'#c7d0dc')
 if d=='a':
  if native:
   for i,t in enumerate(['Callers','Tools','Activity','Config']): p.button(350+i*170,120,t,t==('Callers' if flow=='grant' else 'Tools'),w=155)
  else:
   p.text(70,151,'Broker: running · health unknown',16,MUTED)
   p.text(900,151,'Admin connection: available · fixture 10:42',16,MUTED)
  x,y,w,rx,rw=70,240,860,970,400
  p.text(x,207, 'Callers / writer-demo' if flow=='grant' else 'Tools / '+('weather-demo' if flow=='add' else 'notes-demo'),17,BLUE,550)
 elif d=='b':
  p.box(0,104 if native else 112,245,756,'#eef1f5' if native else NAV,LINE,0)
  fg=INK if native else '#dce4f1'
  p.text(24,154,'WORKSPACE',13,MUTED if native else '#b3c4db',650)
  for i,t in enumerate(['Callers','Tools','Requests','Config']):
   if t==('Callers' if flow=='grant' else 'Tools'): p.box(12,177+i*52,220,42,'#dceaff' if native else '#314965','none',6)
   p.text(28,205+i*52,t,18,fg,550)
  p.text(24,443,'SELECTED',13,MUTED if native else '#b3c4db',650)
  p.text(24,478,'writer-demo' if flow=='grant' else 'weather-demo' if flow=='add' else 'notes-demo',18,fg,600)
  p.text(24,518,'Local admin',16,fg)
  p.text(24,546,'127.0.0.1:8780',16,fg)
  p.text(24,610,'Broker: running',16,fg)
  p.text(24,638,'Health: unknown',16,fg)
  x,y,w,rx,rw=277,205,725,1030,382
  p.text(x,155,FLOWS[flow][0]+' / '+FLOWS[flow][1][step],18,BLUE,550)
 else:
  p.text(32,152,'Callers' if flow=='grant' else 'Tools',17,BLUE,550)
  p.text(880,152,'Local admin · broker running · health unknown',16,MUTED)
  p.box(24,190,250,570,'#edf3fc',LINE,10)
  p.text(44,227,FLOWS[flow][0],20,INK,650)
  for i,t in enumerate(FLOWS[flow][1]):
   p.box(40,260+i*90,218,66,'#fff' if i==step else '#edf3fc', BLUE if i==step else '#edf3fc')
   p.text(54,287+i*90,f'{i+1:02d}',15,BLUE,650); p.text(54,311+i*90,t,16,INK,550)
  p.lines(44,596,['Each stage changes','one kind of authority.','No automatic replay.'],16)
  x,y,w,rx,rw=302,205,720,1050,362
 p.box(x,y,w,585,'#fff',LINE,10 if not native else 8)
 p.box(rx,y,rw,585,'#fbfcfe',LINE,8)
 def head(kicker,title,sub):
  p.text(x+26,y+35,kicker.upper(),13,BLUE,650)
  p.text(x+26,y+75,title,29,INK,650)
  p.text(x+26,y+108,sub,16,MUTED)
 def note(title,lines):
  p.text(rx+22,y+35,title,19,INK,650); p.lines(rx+22,y+72,lines,16)
 def foot(lines): p.lines(rx+22,y+392,lines,16)
 if flow=='grant':
  note('Authority scope',['Caller · writer-demo','Tool · notes-demo','Operation · read_note','','Caller policy controls actions.','SPS controls tool secret access.','This form changes no secrets.'])
  if step==0:
   head('Caller access','Enable before granting','notes-demo is disabled for writer-demo.')
   p.badge(x+26,y+135,'Disabled for caller',w=185)
   p.row(x+26,y+190,w-52,'Tool','notes-demo')
   p.row(x+26,y+239,w-52,'Current operation grants','None loaded for tool')
   p.lines(x+26,y+335,['Enable this tool for this caller, then choose an operation.','Enabling does not select Allow or Human review.','Existing enabled tools and their policies are preserved.'])
   p.button(x+26,y+470,'Enable notes-demo',True,220)
   p.button(x+262,y+470,'Cancel',w=105)
   foot(['Next: policy opens here','only after enable succeeds.','Failed load: Retry; Save locked.'])
  elif step==1:
   head('Policy · draft retained','Grant one operation','Loaded policy · writer-demo / notes-demo')
   p.badge(x+26,y+132,'Tool enabled', 'blue',155)
   p.text(x+26,y+204,'read_note',20,INK,600)
   p.text(x+26,y+232,'Read one note · read operation',16,MUTED)
   for i,t in enumerate(['Deny','Human review','Allow']): p.button(x+26+i*197,y+255,t,i==2,182)
   p.row(x+26,y+319,w-52,'write_note','Deny · unchanged')
   p.box(x+26,y+389,w-52,66,'#fff0f0','#efb3b3')
   p.lines(x+42,y+414,['Save rejected: admin could not apply this update.','Draft kept in this editor. Review the error and retry.'],16,'#8c1f1f')
   p.button(x+26,y+482,'Retry save for writer-demo',True,270)
   p.button(x+314,y+482,'Keep editing',w=150)
   foot(['Draft ≠ saved authority.','All other grants preserved.','Never save a failed/empty load.'])
  else:
   head('Policy receipt','Saved for writer-demo','Admin acknowledged the policy update · fixture 10:42')
   p.badge(x+26,y+138,'Saved','blue',100)
   p.row(x+26,y+201,w-52,'notes-demo · read_note','Allow')
   p.row(x+26,y+250,w-52,'notes-demo · write_note','Deny · unchanged')
   p.lines(x+26,y+350,['A saved policy is not proof of tool health.','No tool was started. No secret mapping was changed.'])
   p.button(x+26,y+482,'Back to callers',True,185)
   foot(['A response lost during save?','Show “Save outcome unknown”.','Reload to compare; keep draft.'])
 elif flow=='add':
  note('Installation scope',['Tool · weather-demo','Source · folder on admin host','Runner · process','','Trusted tools only.','Process mode is not hostile-','code isolation.'])
  foot(['Authoring entry point','Author a tool → Import OpenAPI','Native entry requires contract','repair before it can ship.'])
  if step==0:
   head('Tools · add from source','Add a local folder','The path is on the admin host, not an arbitrary client Mac.')
   p.text(x+26,y+163,'Folder path on local admin',16,INK,600)
   p.box(x+26,y+180,w-52,50); p.text(x+42,y+212,'/srv/demo-tools/weather-demo',18)
   p.lines(x+26,y+267,['Requires toolyard.toml in this folder.','Copies into the managed tools directory.','Adding does not execute code or grant caller access.'])
   p.button(x+26,y+382,'Add from folder',True,210)
   p.button(x+253,y+382,'Cancel',w=110)
   p.text(x+26,y+472,'Author a tool',17,BLUE,550)
   p.button(x+26,y+491,'Import OpenAPI…',w=225)
  elif step==1:
   head('Folder added','Start weather-demo','Copied to /srv/toolstack/tools/weather-demo')
   p.badge(x+26,y+138,'Stopped',w=110)
   p.row(x+26,y+191,w-52,'Process liveness','Not running')
   p.row(x+26,y+240,w-52,'Broker catalog','Not yet registered')
   p.lines(x+26,y+337,['Starting runs this tool’s code as a trusted process.','The runner registers declared secret access with SPS.','Caller grants remain a separate decision.'])
   p.button(x+26,y+482,'Start weather-demo',True,240)
  else:
   head('Broker registration','Restart local broker?','weather-demo was started; catalog reload is still required.')
   p.badge(x+26,y+138,'Alive · health unknown','neutral',226)
   p.lines(x+26,y+220,['Target: local broker at 127.0.0.1:8765','Restart reloads the catalog, including weather-demo.','It interrupts broker availability and may affect active calls.'])
   p.box(x+26,y+309,w-52,109,'#edf3fc',LINE)
   p.lines(x+42,y+337,['After restart: refresh and verify the broker catalog.','Do not display “Registered” from a restart click alone.','If verification fails: “Registration unknown”; keep this context.'],16)
   p.button(x+26,y+482,'Restart local broker',True,245)
   p.button(x+288,y+482,'Not now',w=130)
 elif flow=='recover':
  note('Observed state',['Tool · notes-demo','Runner record · running','Process liveness · not alive','Health · unknown','','A record is not a live process.','No request will be replayed','by this recovery action.'])
  foot(['Requests remain inspect-only.','No audit-delete control.','Lost response ≠ failed action.','Inspect outcome before resubmit.'])
  if step==0:
   head('Tools · needs attention','notes-demo is not alive','Runner record remains, but the process is no longer alive.')
   p.badge(x+26,y+138,'Failed · process absent','bad',230)
   p.row(x+26,y+200,w-52,'Recorded intent','Running')
   p.row(x+26,y+249,w-52,'Observed liveness','Not alive · 10:42')
   p.row(x+26,y+298,w-52,'Secret availability','Unknown · not inspected')
   p.lines(x+26,y+391,['Review the failure, then restart this tool explicitly.','Do not interpret the surviving record as healthy.'])
   p.button(x+26,y+482,'Review restart',True,190)
   p.button(x+234,y+482,'Refresh state',w=170)
  elif step==1:
   head('Recovery · confirmation','Restart notes-demo?','Target: notes-demo on local admin · process runner')
   p.lines(x+26,y+185,['Stops any recorded instance, then starts notes-demo.','The runner re-establishes its declared SPS registration.','Cached secret values are not erased by revocation.'])
   p.box(x+26,y+293,w-52,100,'#fff6df','#e4cc94')
   p.lines(x+42,y+323,['This does not retry previously submitted tool actions.','Their outcomes may be unknown after the crash.','Inspect Requests before submitting a new action.'],16,'#765000')
   p.button(x+26,y+482,'Restart notes-demo',True,230)
   p.button(x+272,y+482,'Cancel',w=110)
  else:
   head('Recovery · response lost','Restart outcome unknown','Admin connection ended before the restart result arrived.')
   p.badge(x+26,y+138,'Unknown','warn',128)
   p.lines(x+26,y+218,['The process may have started. Do not repeat blindly.','Refresh state to reconcile the current observation.','Last known record is shown alongside this outcome.'])
   p.box(x+26,y+315,w-52,106,'#eef1f5',LINE)
   p.lines(x+42,y+345,['Alive alone → “Alive · health unknown”.','Failed observation → “Not alive”.','Only an explicit successful health check → “Healthy”.'],16)
   p.button(x+26,y+482,'Refresh notes-demo state',True,270)
 p.text(30,847, 'Native adaptation · SwiftUI toolbar, grouped forms and sheets; proposed, not a compiled app.' if native else 'Shell wraps this exact web direction · no separate authority or feature set.' if shell else 'Web reference · admin authority / broker caller policy / SPS secret access remain distinct.',16,MUTED)
 if shell: p.text(30,877,'Shell lifecycle: close stops only the admin this shell started. Startup failure must offer visible diagnostics and retry.',15,MUTED)
 else: p.text(30,877,'SOURCE MOCKUP · no live status, credentials, services, or backend mutations · all interactions pictured, not executed',15,MUTED)
 return p.end()

def build():
 screens={}
 for d in DIRECTIONS:
  for surface in ['web','shell','mac']:
   for flow in FLOWS:
    for step in range(3):
     key=f'{d}-{surface}-{flow}-{step}'
     screens[key]=screen(d,surface,flow,step)
     (OUT/f'{key}.svg').write_text(screens[key])
 descriptions=json.dumps(DIRECTIONS)
 # Inline vectors ensure the gallery travels as one file; SVG files are standalone exports.
 html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Toolstack · Three operator directions</title>
<style>*{box-sizing:border-box}body{margin:0;color:#18202a;background:#f6f7f9;font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}header{padding:24px 32px;background:#172033;color:white}h1{font-size:28px;margin:0 0 8px}header p{margin:0;color:#d2dbea}.controls{padding:18px 32px;background:#fff;border-bottom:1px solid #d9dee7}label{display:inline-flex;flex-direction:column;gap:6px;margin:0 20px 12px 0;font-weight:600}select,button{font:inherit;min-height:42px;border:1px solid #aab7c8;border-radius:6px;background:white;color:#18202a;padding:6px 12px}button{cursor:pointer}button:focus-visible,select:focus-visible,a:focus-visible{outline:3px solid #0d6efd;outline-offset:3px}h2{margin:0;font-size:23px}.description{padding:20px 32px;max-width:1350px}.description p{margin:6px 0}.viewport{overflow:auto;margin:0 24px;border:1px solid #d9dee7;background:white}.viewport svg{display:block;width:1440px;height:900px;max-width:none}.viewport.fit svg{width:100%;height:auto}.foot{padding:24px 32px;max-width:1250px}a{color:#0754b9}details{margin-top:18px}summary{cursor:pointer;font-weight:600}code{background:#edf1f5;padding:2px 5px}@media print{header,.controls,.foot{display:none}.viewport{margin:0;border:0}.viewport svg{width:100%;height:auto}}</style>
<header><h1>Toolstack / Three operator directions</h1><p>Design review only · fictional data · no direction selected · no decision submission</p></header>
<div class="controls"><label>Direction<select id="direction"><option value="a">01 · Clear desk</option><option value="b">02 · Operator workbench</option><option value="c">03 · Guided ledger</option></select></label><label>Surface<select id="surface"><option value="web">Admin web · desktop</option><option value="shell">Desktop webview shell</option><option value="mac">Native Mac adaptation</option></select></label><label>Primary flow<select id="flow"><option value="grant">Grant on a disabled tool</option><option value="add">Add / start / register folder</option><option value="recover">Recover crashed tool</option></select></label><label>Flow frame<select id="step"></select></label><button id="fit" aria-pressed="false">Fit to width</button><button id="download">Download this SVG</button></div>
<section class="description" aria-live="polite"><h2 id="title"></h2><p id="desc"></p><p><strong>Merit:</strong> <span id="merit"></span> <strong>Tradeoff:</strong> <span id="trade"></span></p></section><div class="viewport" id="viewport"></div>
<div class="foot"><strong>Read at 100%:</strong> each frame is 1440 × 900. Scroll horizontally on smaller windows, or choose Fit to width. Pictured application controls are static. Gallery controls only change the view or download a local vector.
<details><summary>Evidence and limits</summary><p>Source reference: admin/views/assets.py (blue #0d6efd, navy #172033, light #f6f7f9), admin/views/tools.py, desktop/app.py, SwiftUI ToolstackApp.swift; checkout 06df1b1. The Mac frames are native-layout design proposals, not SwiftUI screenshots. Health, draft, error and confirmation treatments require implementation and live verification after selection.</p><p>Healthy is reserved for an explicit positive health check. Existing process liveness alone cannot establish health; these fixtures therefore show health unknown. Registration requires broker restart and catalog verification, not an invented Register API. OpenAPI has a native signifier; contract repair is a prerequisite. Draft retention is a requirement, not proof of crash persistence.</p><p>Chief recommendation: 01 · Clear desk for continuity and bounded scope. The principal chooses through the chief’s single card. This file does not submit a choice. Principal rejection count: 0; stop project at 2.</p></details></div>
<script>const screens=SCREENS, directions=DIRECTIONS, flows=FLOWS;
const $=id=>document.getElementById(id); let key;
function stages(){const old=$('step').value; $('step').replaceChildren(...flows[$('flow').value][1].map((s,i)=>new Option(`${i+1} · ${s}`,i))); $('step').value=old||'0';}
function show(){const d=$('direction').value;key=[d,$('surface').value,$('flow').value,$('step').value].join('-'); $('viewport').innerHTML=screens[key];$('title').textContent=directions[d][0]+' — '+directions[d][1];$('desc').textContent=directions[d][2];$('merit').textContent=directions[d][3];$('trade').textContent=directions[d][4];history.replaceState(null,'','#'+key);}
for(const id of ['direction','surface','step'])$(id).addEventListener('change',show);
$('flow').addEventListener('change',()=>{stages();show()});$('fit').onclick=()=>{const fit=$('viewport').classList.toggle('fit');$('fit').setAttribute('aria-pressed',fit);$('fit').textContent=fit?'Show at 100%':'Fit to width'};
$('download').onclick=()=>{const url=URL.createObjectURL(new Blob([screens[key]],{type:'image/svg+xml'}));const a=document.createElement('a');a.href=url;a.download=key+'.svg';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
const initial=location.hash.slice(1).split('-');if(initial.length===4&&screens[initial.join('-')]){ $('direction').value=initial[0];$('surface').value=initial[1];$('flow').value=initial[2]; stages();$('step').value=initial[3];}else stages();show();</script></html>'''
 html=html.replace('SCREENS',json.dumps(screens).replace('</','<\\/')).replace('DIRECTIONS',descriptions).replace('FLOWS',json.dumps(FLOWS))
 (ROOT/'gallery.html').write_text(html)
 print(f'Wrote self-contained gallery and {len(screens)} SVG frames')

if __name__=='__main__': build()
