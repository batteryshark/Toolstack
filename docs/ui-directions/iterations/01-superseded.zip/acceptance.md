# Design acceptance — source mockups, not product certification

Interface-design was explicitly selected. Loaded `norman/SKILL.md` while designing and `norman-audit/SKILL.md` before acceptance, plus cognition and interaction-cost references. The bundled dependency-free `norman_audit_recon.py` collector ran on admin, desktop, macapp and the gallery. Its zero findings do **not** establish usability: Python-generated HTML, SwiftUI and SVG drawings escape its form/state heuristics. `evidence/*.json` retains these caveats.

## Primary-task walkthrough

Counts below are **proposed source-design paths**, not measured usability, not completed application interactions. Start signed in on the default pane. Each control activation or completed field entry counts once; reading, waiting, scrolling and login are excluded. Frames capture decision states, not every navigation click. Error retries add actions and are excluded from these happy-path counts.

- **Grant an existing caller one operation on a disabled tool — 6:** open Callers; choose writer-demo; choose disabled notes-demo; Enable notes-demo; select Allow for read_note; Save for writer-demo. Enable success advances to the policy editor without reopening a menu. Inspect-only receipt then names the saved policy and unchanged deny. Web and shell use the same flow; Mac uses its caller list and editor. The six-action route is a design target, not a claimed measured reduction from the review.
- **Add/start/register local folder — 7:** open Tools; Add from folder; enter host folder path; Add; Start weather-demo; confirm Restart local broker; refresh/verify catalog. The last refresh/registered result is specified in the screen and README but not a separate rendered frame. If start or restart fails, remain at that stage; no implied rollback of a successfully copied folder.
- **Recover crashed tool — 5:** open Tools; select notes-demo; Review restart; Restart notes-demo; Refresh state. Confirmation and outcome reconciliation deliberately add friction versus the old two-action stopped-tool path; they prevent claiming a lost action is safe to repeat. No reduction is asserted.

All three directions keep these authority transitions. A emphasizes document clarity, B preserves entity context, C makes stage sequence explicit. Do not add Next clicks purely to animate C’s stage rail.

## Five-question review

**Earned place:** one task action dominates each frame. Scope/observed-state inspectors are justified by caller-vs-tool and record-vs-liveness confusion. No decorative metric counters, automated repair, secret-value editors or batch grants. Gallery controls exist only for review.

**Find it:** tool access leads directly to enable then policy; Tools leads to Add from folder and explicit Import OpenAPI. Failed tool state exposes recovery rather than disabling Start because a record exists. Requests stays away from audit destruction.

**Cost:** targets and prior choices remain on screen; host path is entered once; unchanged grants need no re-entry. C spends horizontal space and attention on sequence, B on persistent context, A on roomy documents. Proposed counts above make no speed/telemetry claims.

**Know it worked:** rejected save keeps editor and draft; acknowledged save has a scoped receipt; missing restart response is Unknown with Refresh as the next action. No blanket green “all good” state. Healthy requires evidence not currently supplied by the listing.

**Survive the walk:** first use explains add/start/register distinctions inline; repeated use has stable labels and target context. Resume cue, dirty navigation guard and failed-load Save lock are requirements in README; drawings cannot prove state persistence. Hundredth-use suitability remains a live/usability check, especially for C’s rail and B’s density.

## Ranked acceptance caveats

These are **remaining implementation/live-check gates**, not claims that the delivered drawings repaired source:

- **S3 trap:** failed native policy load currently permits an empty save; lock save until successful load and retain prior state. [`macapp/Sources/ToolstackApp/ToolstackApp.swift:521–530,590–598`]
- **S3 amnesia:** native failed save dismisses the editor; dismiss only on explicit success, preserve draft and target on failure/unknown. [`macapp/Sources/ToolstackApp/ToolstackApp.swift:533–540`]
- **S3 mute:** native running color follows a record, not process liveness; decode/display observations separately and allow recovery. [`macapp/Sources/ToolstackApp/ToolstackApp.swift:344–355`; `admin/toolyard_ops.py:56–65`]
- **S2 orphan:** native OpenAPI requires a visible authoring entry and repaired contract before enabling it. [`macapp/Sources/ToolstackKit/ApiClient.swift:120–122`; `docs/ui-directions/build_gallery.py`, add-folder frame]
- **S2 mute:** startup errors need a double-click-visible shell recovery surface. [`desktop/app.py:106–123`]
- **S2 trap:** SVG controls are not operable application widgets; keyboard/focus/VoiceOver and non-destructive persistence need a real implementation and live check. Gallery controls have labels and focus CSS, but no runtime accessibility compliance claim. [`docs/ui-directions/build_gallery.py`]

No S4 finding is claimed for this design pack. Product acceptance is pending; **design handoff is usable**. Native frames are native-layout proposals, not compiled SwiftUI evidence. Shell/web identity is shared by the generator, with only frame/lifecycle text changed.

## Checks performed and limits

- Standard-library generator ran; standalone SVGs parse and carry title/accessible image labels. Structural verification checks direction × surface × flow × stage coverage and ownership.
- Existing installed Chrome used **headlessly**, file-only, with isolated temporary profile, disabled background networking/sync, no Toolstack server, GUI, VM or installed service. Nine PNG outputs succeeded; representative A web, B native and C shell were visually inspected for clipping/legibility. This is **mockup-render evidence**, not a live product test.
- Gallery hash route `#c-mac-add-0` executed offscreen and populated its SVG viewport. It establishes gallery startup, not every gallery control or application interaction. Renderer emits macOS display-link/task-policy diagnostics despite successful PNG output; raw logs retained.
- Bundled collector outputs retained separately from manual findings. Baseline source is frozen at `06df1b1`; source reads only, no runtime tests/builds of admin/desktop/Mac attempted.
- No live timing, computed target sizing, screen-reader behavior, system-sheet keyboard behavior, production health, registrations, secret state or draft durability verified. Static dimensions are design geometry only.
- No two failed approaches occurred; existing offscreen Chrome worked on the first approach. Simplest route chosen: static SVGs plus one self-contained HTML, no service. No heavy product checks were run; render/structural checks are the design milestone only.

net: -0 controls, -0 steps, +1 signifier needed.

This net is the conservative **implementation** ledger (native OpenAPI entry), not a claim to have changed the running UI. The visual signifier is already included in all native add-folder mockups.
